package fraude;

import etude.Epreuve;
import etude.Etudiant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class GestionnaireFraudesTest {

    private GestionnaireFraudes gestionnaire;

    @BeforeEach
    void setUp() {
        gestionnaire = new GestionnaireFraudes();
    }

    private Etudiant creerEtudiant(String numero, String nom, String prenom) {
        Etudiant etudiant = new Etudiant();
        etudiant.setNumeroApprenant(numero);
        etudiant.setNom(nom);
        etudiant.setPrenom(prenom);
        return etudiant;
    }

    private FormulaireFraude creerFormulaire(Epreuve epreuve, Etudiant... etudiants) {
        FraudeIAG fraude = new FraudeIAG("ChatGPT");
        for (Etudiant etudiant : etudiants) {
            fraude.addEtudiant(etudiant);
        }
        FormulaireFraude formulaire = new FormulaireFraude();
        formulaire.setEpreuve(epreuve);
        formulaire.ajouterFraudeConstatee(fraude);
        return formulaire;
    }

    @Test
    void testAjouterFormulaire() {
        Epreuve epreuve = new Epreuve();
        Etudiant etudiant = creerEtudiant("001", "MORIN", "Basile");
        FormulaireFraude formulaire1 = creerFormulaire(epreuve, etudiant);
        FormulaireFraude formulaire2 = creerFormulaire(epreuve, etudiant);

        gestionnaire.ajouterFormulaire(formulaire1);
        gestionnaire.ajouterFormulaire(formulaire2);

        assertEquals(List.of(formulaire1, formulaire2), gestionnaire.getFormulaires());
        assertEquals(List.of(etudiant), gestionnaire.getEtudiants());
        assertEquals(List.of(epreuve), gestionnaire.getEpreuves());
        assertEquals(0, formulaire1.getId());
        assertEquals(1, formulaire2.getId());
    }

    @Test
    void testSupprimerFormulaire() {
        Epreuve epreuve1 = new Epreuve();
        Epreuve epreuve2 = new Epreuve();
        Etudiant etudiant1 = creerEtudiant("001", "MORIN", "Basile");
        Etudiant etudiant2 = creerEtudiant("002", "DUPONT", "Alice");
        FormulaireFraude formulaire1 = creerFormulaire(epreuve1, etudiant1);
        FormulaireFraude formulaire2 = creerFormulaire(epreuve2, etudiant2);
        gestionnaire.ajouterFormulaire(formulaire1);
        gestionnaire.ajouterFormulaire(formulaire2);

        assertTrue(gestionnaire.supprimerFormulaire(formulaire1.getId()));
        assertFalse(gestionnaire.supprimerFormulaire(999));
        assertEquals(List.of(formulaire2), gestionnaire.getFormulaires());
        assertEquals(List.of(etudiant2), gestionnaire.getEtudiants());
        assertEquals(List.of(epreuve2), gestionnaire.getEpreuves());
    }

    @Test
    void testRechercherFormulairesParEtudiants() {
        Epreuve epreuve = new Epreuve();
        Etudiant recherche = creerEtudiant("001", "MORIN", "Basile");
        Etudiant absent = creerEtudiant("999", "ABSENT", "Absent");
        FormulaireFraude formulaire = creerFormulaire(epreuve, recherche);
        gestionnaire.ajouterFormulaire(formulaire);

        assertEquals(List.of(formulaire), gestionnaire.rechercherFormulairesParEtudiants(recherche));
        assertTrue(gestionnaire.rechercherFormulairesParEtudiants(absent).isEmpty());
    }

    @Test
    void testRechercherFormulaireParEpreuve() {
        Epreuve epreuve = new Epreuve();
        Epreuve absente = new Epreuve();
        FormulaireFraude formulaire = creerFormulaire(epreuve);
        gestionnaire.ajouterFormulaire(formulaire);

        assertEquals(List.of(formulaire), gestionnaire.rechercherFormulaireParEpreuve(epreuve));
        assertTrue(gestionnaire.rechercherFormulaireParEpreuve(absente).isEmpty());
    }

    @Test
    void testRechercherEtudiantsParNumero() {
        Etudiant etudiant = creerEtudiant("001", "MORIN", "Basile");
        gestionnaire.ajouterFormulaire(creerFormulaire(new Epreuve(), etudiant));

        assertEquals(List.of(etudiant), gestionnaire.rechercherEtudiantsParNumero("001"));
        assertTrue(gestionnaire.rechercherEtudiantsParNumero("999").isEmpty());
    }

    @Test
    void testRechercherEtudiantsParNom() {
        Etudiant etudiant = creerEtudiant("001", "MORIN", "Basile");
        gestionnaire.ajouterFormulaire(creerFormulaire(new Epreuve(), etudiant));

        assertEquals(List.of(etudiant), gestionnaire.rechercherEtudiantsParNom("MORIN"));
        assertTrue(gestionnaire.rechercherEtudiantsParNom("DUPONT").isEmpty());
    }

    @Test
    void testRechercherEtudiantsParPrenom() {
        Etudiant etudiant = creerEtudiant("001", "MORIN", "Basile");
        gestionnaire.ajouterFormulaire(creerFormulaire(new Epreuve(), etudiant));

        assertEquals(List.of(etudiant), gestionnaire.rechercherEtudiantsParPrenom("Basile"));
        assertTrue(gestionnaire.rechercherEtudiantsParPrenom("Alice").isEmpty());
    }

    @Test
    void testGetters() {
        Epreuve epreuve = new Epreuve();
        Etudiant etudiant = creerEtudiant("001", "MORIN", "Basile");
        FormulaireFraude formulaire = creerFormulaire(epreuve, etudiant);
        gestionnaire.ajouterFormulaire(formulaire);

        assertEquals(List.of(formulaire), gestionnaire.getFormulaires());
        assertEquals(List.of(etudiant), gestionnaire.getEtudiants());
        assertEquals(List.of(epreuve), gestionnaire.getEpreuves());
    }

    @Test
    void testReconstruireEtudiantsEtEpreuves() {
        Epreuve epreuve = new Epreuve();
        Etudiant etudiant1 = creerEtudiant("001", "MORIN", "Basile");
        Etudiant etudiant2 = creerEtudiant("002", "DUPONT", "Alice");
        gestionnaire.ajouterFormulaire(creerFormulaire(epreuve, etudiant1));
        gestionnaire.ajouterFormulaire(creerFormulaire(epreuve, etudiant1, etudiant2));
        gestionnaire.getEtudiants().clear();
        gestionnaire.getEpreuves().clear();

        gestionnaire.reconstruireEtudiantsEtEpreuves();

        assertEquals(2, gestionnaire.getEtudiants().size());
        assertTrue(gestionnaire.getEtudiants().contains(etudiant1));
        assertTrue(gestionnaire.getEtudiants().contains(etudiant2));
        assertEquals(List.of(epreuve), gestionnaire.getEpreuves());
    }
}
