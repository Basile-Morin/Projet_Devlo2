package fraude;

import etude.Etudiant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StatistiquesFraudesTest {

    private StatistiquesFraudes statistiques;

    @BeforeEach
    void setUp() {
        statistiques = new StatistiquesFraudes();
    }

    private Etudiant creerEtudiant(String numero) {
        Etudiant etudiant = new Etudiant();
        etudiant.setNumeroApprenant(numero);
        return etudiant;
    }

    private FormulaireFraude creerFormulaire(Etudiant etudiant, int nombreFraudes) {
        FormulaireFraude formulaire = new FormulaireFraude();
        for (int i = 0; i < nombreFraudes; i++) {
            FraudeIAG fraude = new FraudeIAG();
            fraude.addEtudiant(etudiant);
            formulaire.ajouterFraudeConstatee(fraude);
        }
        return formulaire;
    }

    @Test
    void testNombreTotalFormulaires() {
        assertEquals(0, statistiques.nombreTotalFormulaires(null));
        assertEquals(2, statistiques.nombreTotalFormulaires(List.of(new FormulaireFraude(), new FormulaireFraude())));
    }

    @Test
    void testNombreEtudiantsDistincts() {
        Etudiant etudiant1 = creerEtudiant("001");
        Etudiant etudiant1Copie = creerEtudiant("001");
        Etudiant etudiant2 = creerEtudiant("002");
        List<FormulaireFraude> formulaires = List.of(creerFormulaire(etudiant1, 1), creerFormulaire(etudiant1Copie, 1), creerFormulaire(etudiant2, 1));

        assertEquals(0, statistiques.nombreEtudiantsDistincts(null));
        assertEquals(2, statistiques.nombreEtudiantsDistincts(formulaires));
    }

    @Test
    void testNombreTotalFraudes() {
        Etudiant etudiant = creerEtudiant("001");
        List<FormulaireFraude> formulaires = List.of(creerFormulaire(etudiant, 1), creerFormulaire(etudiant, 2));

        assertEquals(0, statistiques.nombreTotalFraudes(null));
        assertEquals(3, statistiques.nombreTotalFraudes(formulaires));
    }

    @Test
    void testMoyenneFraudesParFormulaire() {
        Etudiant etudiant = creerEtudiant("001");
        List<FormulaireFraude> formulaires = List.of(creerFormulaire(etudiant, 1), creerFormulaire(etudiant, 3));

        assertEquals(0.0, statistiques.moyenneFraudesParFormulaire(null));
        assertEquals(0.0, statistiques.moyenneFraudesParFormulaire(List.of()));
        assertEquals(2.0, statistiques.moyenneFraudesParFormulaire(formulaires));
    }

    @Test
    void testEcartTypeFraudesParFormulaire() {
        Etudiant etudiant = creerEtudiant("001");
        List<FormulaireFraude> formulaires = List.of(creerFormulaire(etudiant, 1), creerFormulaire(etudiant, 3));

        assertEquals(0.0, statistiques.ecartTypeFraudesParFormulaire(null));
        assertEquals(0.0, statistiques.ecartTypeFraudesParFormulaire(List.of()));
        assertEquals(1.0, statistiques.ecartTypeFraudesParFormulaire(formulaires));
    }
}
