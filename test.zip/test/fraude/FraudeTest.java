package fraude;

import etude.Etudiant;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class FraudeTest {

    @Test
    void testAddEtudiant() {
        Fraude fraude = new FraudeIAG();
        Etudiant etudiant = new Etudiant();
        fraude.addEtudiant(etudiant);
        assertTrue(fraude.getEtudiants().contains(etudiant));
    }

    @Test
    void testRemoveEtudiant() {
        Fraude fraude = new FraudeIAG();
        Etudiant etudiant = new Etudiant();
        fraude.addEtudiant(etudiant);
        fraude.removeEtudiant(etudiant);
        assertFalse(fraude.getEtudiants().contains(etudiant));
    }

    @Test
    void testGettersSetters() {
        Fraude fraude = new FraudeIAG();
        Etudiant etudiant = new Etudiant();
        assertTrue(fraude.getEtudiants().isEmpty());
        assertEquals(LocalDate.now(), fraude.getDateReleve());

        List<Etudiant> etudiants = new ArrayList<>();
        etudiants.add(etudiant);
        LocalDate date = LocalDate.of(2026, 6, 9);
        fraude.setEtudiants(etudiants);
        fraude.setContenu("Contenu");
        fraude.setDescription("Description");
        fraude.setDateReleve(date);

        assertEquals(etudiants, fraude.getEtudiants());
        assertThrows(UnsupportedOperationException.class, () -> fraude.getEtudiants().clear());
        assertEquals("Contenu", fraude.getContenu());
        assertEquals("Description", fraude.getDescription());
        assertEquals(date, fraude.getDateReleve());
    }
}
