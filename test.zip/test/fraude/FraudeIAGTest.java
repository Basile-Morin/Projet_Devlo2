package fraude;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FraudeIAGTest {

    @Test
    void testConstructeursGettersSetters() {
        assertNull(new FraudeIAG().getNomService());
        FraudeIAG fraude = new FraudeIAG("ChatGPT");
        assertEquals("ChatGPT", fraude.getNomService());
        fraude.setNomService("Gemini");
        assertEquals("Gemini", fraude.getNomService());
    }
}
