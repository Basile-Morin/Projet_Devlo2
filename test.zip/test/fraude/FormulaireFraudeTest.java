package fraude;

import etude.Epreuve;
import etude.Etudiant;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class FormulaireFraudeTest {

    private Etudiant creerEtudiant(String numero) {
        Etudiant etudiant = new Etudiant();
        etudiant.setNumeroApprenant(numero);
        return etudiant;
    }

    private Fraude creerFraude(Etudiant... etudiants) {
        Fraude fraude = new FraudeIAG();
        for (Etudiant etudiant : etudiants) fraude.addEtudiant(etudiant);
        return fraude;
    }

    private Fraude creerFraudeSansEtudiants() {
        return new FraudeIAG() {
            @Override
            public List<Etudiant> getEtudiants() {
                return null;
            }
        };
    }

    @Test
    void testConstructeurs() {
        FormulaireFraude vide = new FormulaireFraude();
        assertTrue(vide.getFraudes().isEmpty());
        assertTrue(vide.getEtudiants().isEmpty());
        assertNotNull(vide.getDateCreation());
        assertEquals(vide.getDateCreation(), vide.getDateDerniereModification());

        Etudiant e1 = creerEtudiant("001");
        Etudiant e2 = creerEtudiant("002");
        FormulaireFraude rempli = new FormulaireFraude(List.of(creerFraude(e1, e2), creerFraude(e2)));
        assertEquals(2, rempli.getFraudes().size());
        assertEquals(2, rempli.getEtudiants().size());
        assertTrue(new FormulaireFraude(null).getFraudes().isEmpty());
    }

    @Test
    void testAjouterFraudeConstatee() {
        FormulaireFraude formulaire = new FormulaireFraude();
        Etudiant e1 = creerEtudiant("001");
        Etudiant e2 = creerEtudiant("002");
        formulaire.ajouterFraudeConstatee(null);
        formulaire.ajouterFraudeConstatee(creerFraude(e1, e2));
        formulaire.ajouterFraudeConstatee(creerFraude(e2));
        formulaire.ajouterFraudeConstatee(creerFraudeSansEtudiants());

        assertEquals(3, formulaire.getFraudes().size());
        assertEquals(List.of(e1, e2), formulaire.getEtudiants());
    }

    @Test
    void testRetirerFraudeConstatee() {
        FormulaireFraude formulaire = new FormulaireFraude();
        Etudiant e1 = creerEtudiant("001");
        Etudiant e2 = creerEtudiant("002");
        Etudiant e3 = creerEtudiant("003");
        Fraude fraude1 = creerFraude(e1, e2);
        Fraude fraude2 = creerFraude(e2, e3);
        formulaire.ajouterFraudeConstatee(fraude1);
        formulaire.ajouterFraudeConstatee(fraude2);
        formulaire.ajouterFraudeConstatee(creerFraudeSansEtudiants());

        formulaire.retirerFraudeConstatee(null);
        formulaire.retirerFraudeConstatee(creerFraude(e1));
        formulaire.retirerFraudeConstatee(fraude1);

        assertFalse(formulaire.getFraudes().contains(fraude1));
        assertFalse(formulaire.getEtudiants().contains(e1));
        assertTrue(formulaire.getEtudiants().containsAll(List.of(e2, e3)));
    }

    @Test
    void testGettersSetters() {
        FormulaireFraude formulaire = new FormulaireFraude();
        Epreuve epreuve = new Epreuve();
        Fraude fraude = creerFraude(creerEtudiant("001"));
        LocalDateTime creation = LocalDateTime.of(2026, 6, 8, 9, 0);
        LocalDateTime modification = LocalDateTime.of(2026, 6, 9, 10, 0);

        formulaire.ajouterFraudeConstatee(fraude);
        formulaire.setEpreuve(epreuve);
        formulaire.setDateCreation(null);
        formulaire.setDateCreation(creation);
        formulaire.setDateDerniereModification(null);
        formulaire.setDateDerniereModification(modification);
        formulaire.setId(42);

        assertEquals(List.of(fraude), formulaire.getFraudes());
        assertEquals(fraude.getEtudiants(), formulaire.getEtudiants());
        assertThrows(UnsupportedOperationException.class, () -> formulaire.getFraudes().clear());
        assertThrows(UnsupportedOperationException.class, () -> formulaire.getEtudiants().clear());
        assertSame(epreuve, formulaire.getEpreuve());
        assertEquals(creation, formulaire.getDateCreation());
        assertEquals(42, formulaire.getId());
        assertFalse(formulaire.getDateDerniereModification().isBefore(modification));
    }
}
