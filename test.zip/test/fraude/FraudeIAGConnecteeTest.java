package fraude;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FraudeIAGConnecteeTest {

    @Test
    void testConstructeursGettersSetters() {
        assertNull(new FraudeIAGConnectee().getAdresseIP());
        FraudeIAGConnectee fraude = new FraudeIAGConnectee("ChatGPT", "192.168.1.1");
        assertEquals("ChatGPT", fraude.getNomService());
        assertEquals("192.168.1.1", fraude.getAdresseIP());
        fraude.setAdresseIP("10.0.0.1");
        assertEquals("10.0.0.1", fraude.getAdresseIP());
    }
}
