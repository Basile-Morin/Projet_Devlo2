import etude.Epreuve;
import etude.Etudiant;
import fraude.Fraude;

import java.util.List;
import java.util.Scanner;

public class MenuConsole {

    private final GestionnaireFraudes gestionnaire;
    private final Scanner scanner;

    public MenuConsole(GestionnaireFraudes gestionnaire) {
        this.gestionnaire = gestionnaire;
        this.scanner = new Scanner(System.in);
    }

    public void afficherMenu() {
        System.out.println("===== MENU CONSOLE =====");
        System.out.println("1. Afficher les formulaires");
        System.out.println("2. Ajouter un formulaire");
        System.out.println("3. Supprimer un formulaire");
        System.out.println("4. Afficher les recherches");
        System.out.println("5. Afficher les statistiques");
        System.out.println("6. Afficher le graphe");
        System.out.println("7. Afficher les étudiants existants");
        System.out.println("8. Afficher les épreuves existantes");
        System.out.println("0. Quitter");
    }

    public void lancer() {
        int choix=1;

        while (choix != 0){
            afficherMenu();
            System.out.print("Votre choix : ");
            choix = scanner.nextInt();

            switch (choix) {
                case 1:
                    afficherFormulaires();
                    break;
                case 2:
                    ajouterFormulaire();
                    break;
                case 3:
                    supprimerFormulaire();
                    break;
                case 4:
                    afficherRecherches();
                    break;
                case 5:
                    afficherStatistiques();
                    break;
                case 6:
                    afficherGraphe();
                    break;
                case 7:
                    afficherEtudiants();
                    break;
                case 8:
                    afficherEpreuves();
                    break;
                case 0:
                    System.out.println("Fin du programme.");
                    break;
                default:
                    System.out.println("Choix invalide.");
                    break;
            }

            System.out.println();

        }
    }

    public void afficherFormulaires() {
        System.out.println("===== FORMULAIRES =====");

        for (FormulaireFraude formulaire : gestionnaire.getFormulaires()) {
            System.out.println("\nFormulaire n°" + formulaire.getId());
            System.out.println("Épreuve : " + formulaire.getEpreuve());

            System.out.println("Étudiants concernés :");
            for (Etudiant etudiant : formulaire.getEtudiants()) {
                afficherEtudiant(etudiant);
            }

            System.out.println("Fraudes constatées :");
            for (Fraude fraude : formulaire.getFraudes()) {
                System.out.println(" - " + fraude.getClass().getSimpleName());
            }
        }
    }

    public void ajouterFormulaire() {
        FormulaireFraude formulaire = new FormulaireFraude();


        /*
         * Pour l'instant, on crée une épreuve vide.
         * Plus tard, tu pourras demander le code ECUE, la date, l'heure, etc.
         */
        Epreuve epreuve = new Epreuve();
        formulaire.setEpreuve(epreuve);

        gestionnaire.ajouterFormulaire(formulaire);

        System.out.println("Formulaire n°" + formulaire.getId() + " ajouté.");
    }

    public void supprimerFormulaire() {
        System.out.print("Id du formulaire à supprimer : ");
        int id = scanner.nextInt();

        boolean supprime = gestionnaire.supprimerFormulaire(id);

        if (supprime) {
            System.out.println("Formulaire n°" + id + " supprimé.");
        } else {
            System.out.println("Aucun formulaire avec l'id " + id + " trouvé.");
        }
    }

    public void afficherRecherches() {
        System.out.println("===== RECHERCHES =====");
        System.out.println("1. Rechercher des étudiants par nom");
        System.out.println("2. Rechercher des étudiants par prénom");

        System.out.print("Votre choix : ");
        int choix = scanner.nextInt();
        scanner.nextLine();

        switch (choix) {
            case 1:
                rechercherParNom();
                break;
            case 2:
                rechercherParPrenom();
                break;
            default:
                System.out.println("Choix invalide.");
                break;
        }
    }

    private void rechercherParNom() {
        System.out.print("Nom recherché : ");
        String nom = scanner.nextLine();

        List<Etudiant> resultats = gestionnaire.rechercherEtudiantsParNom(nom);

        System.out.println("Résultat(s) :");
        for (Etudiant etudiant : resultats) {
            afficherEtudiant(etudiant);
        }
    }

    private void rechercherParPrenom() {
        System.out.print("Prénom recherché : ");
        String prenom = scanner.nextLine();

        List<Etudiant> resultats = gestionnaire.rechercherEtudiantsParPrenom(prenom);

        System.out.println("Résultat(s) :");
        for (Etudiant etudiant : resultats) {
            afficherEtudiant(etudiant);
        }
    }

    StatistiquesFraudes statistiquesFraudes = new StatistiquesFraudes();

    public void afficherStatistiques() {
        System.out.println("===== STATISTIQUES =====");

        System.out.println("Nombre total de formulaires : "
                + statistiquesFraudes.nombreTotalFormulaires(gestionnaire.getFormulaires()));

        System.out.println("Nombre total de fraudes : "
                + statistiquesFraudes.nombreTotalFraudes(gestionnaire.getFormulaires()));

        System.out.println("Nombre d'étudiants distincts : "
                + statistiquesFraudes.nombreEtudiantsDistincts(gestionnaire.getFormulaires()));

        System.out.printf("Moyenne de fraudes par formulaire : %.2f \n",
                statistiquesFraudes.moyenneFraudesParFormulaire(gestionnaire.getFormulaires()));

        System.out.printf("Écart-type des fraudes par formulaire : %.2f \n",
                statistiquesFraudes.ecartTypeFraudesParFormulaire(gestionnaire.getFormulaires()));
    }

    public void afficherGraphe() {
        GrapheFraudeurs graphe = new GrapheFraudeurs();

        graphe.construireGraphe(gestionnaire.getFormulaires());
        graphe.afficherGraphe();
    }

    private void afficherEtudiant(Etudiant etudiant) {
        System.out.println(" - "
                + etudiant.getNumeroApprenant()
                + " : "
                + etudiant.getPrenom()
                + " "
                + etudiant.getNom());
    }

    public void afficherEtudiants() {
        System.out.println("===== ÉTUDIANTS EXISTANTS =====");

        for (Etudiant etudiant : gestionnaire.getEtudiants()) {
            afficherEtudiant(etudiant);
        }
    }

    public void afficherEpreuves() {
        System.out.println("===== ÉPREUVES EXISTANTES =====");

        for (Epreuve epreuve : gestionnaire.getEpreuves()) {
            afficherEpreuve(epreuve);
        }
    }

    private void afficherEpreuve(Epreuve epreuve) {
        System.out.println(" - Code ECUE : " + epreuve.getCodeECUE()
                + " | Date : " + epreuve.getDate()
                + " | Heure : " + epreuve.getHeure()
                + " | Durée : " + epreuve.getDuree()
                + " min"
                + " | Modalité : " + epreuve.getModalite());
    }

    public static void main(String[] args) {
        /*
         * MAIN DE TEST UNIQUEMENT.
         * Dans le programme final, tu créeras un vrai GestionnaireFraudes,
         * puis tu lanceras le menu avec menu.lancer().
         */

        GestionnaireFraudes gestionnaire = JeuDonneesTest.creerDonneesTest();
        MenuConsole menu = new MenuConsole(gestionnaire);

        System.out.println("\nTEST afficherMenu()");
        menu.afficherMenu();

        System.out.println("\nTEST afficherFormulaires()");
        menu.afficherFormulaires();

        System.out.println("\nTEST afficherStatistiques()");
        menu.afficherStatistiques();

        System.out.println("\nTEST afficherGraphe()");
        menu.afficherGraphe();

        menu.lancer();
    }

}